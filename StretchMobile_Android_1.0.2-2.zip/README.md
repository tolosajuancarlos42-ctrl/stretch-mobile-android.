# Stretch Mobile 1.0.2

Proyecto Android inicial para compilar una APK de depuración mediante GitHub Actions.

## Compilación
El workflow `.github/workflows/build-apk.yml` compila automáticamente al subir cambios a `principal` o `main`, o manualmente desde Actions.

## Limitaciones
Esta versión es una interfaz inicial. El control de escala es una vista previa y no estira la imagen de Free Fire ni desbloquea FPS. La frecuencia informada por Android no garantiza los FPS del juego.
