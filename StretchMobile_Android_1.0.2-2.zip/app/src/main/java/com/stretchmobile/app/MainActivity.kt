package com.stretchmobile.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 15, 15)
        window.navigationBarColor = Color.rgb(15, 15, 15)

        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(15, 15, 15)) }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 34, 24, 24)
        }
        scroll.addView(layout)
        setContentView(scroll)

        fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(8, 12, 8, 12)
            }

        val red = Color.rgb(255, 55, 55)
        val white = Color.WHITE
        layout.addView(label("STRETCH MOBILE", 28f, red, true))
        layout.addView(label("AJUSTES PARA TU EXPERIENCIA GAMER", 13f, white, true))
        layout.addView(label("Panel de configuración", 20f, white, true))

        val info = label("Dispositivo detectado: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}", 14f, Color.LTGRAY)
        layout.addView(info)

        layout.addView(label("Escala de vista previa", 18f, white, true))
        val value = label("100%", 24f, red, true)
        layout.addView(value)
        val seek = SeekBar(this).apply {
            max = 50
            progress = 0
        }
        layout.addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                value.text = "${100 + progress}%"
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        layout.addView(label("Frecuencia de pantalla", 18f, white, true))
        val hz = if (android.os.Build.VERSION.SDK_INT >= 23) {
            try { window.decorView.display?.refreshRate?.toInt() ?: 60 } catch (_: Exception) { 60 }
        } else 60
        layout.addView(label("Frecuencia informada por Android: ${hz} Hz", 15f, Color.LTGRAY))

        layout.addView(label("Importante", 18f, red, true))
        layout.addView(label(
            "Esta versión es una primera app de configuración y vista previa. El control de escala no modifica Free Fire ni desbloquea FPS. Para cambiar la imagen real del juego se necesitan permisos y compatibilidad que esta versión todavía no implementa.",
            14f, Color.LTGRAY
        ))
    }
}
