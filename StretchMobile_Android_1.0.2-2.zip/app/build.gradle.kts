plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.stretchmobile.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.stretchmobile.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "1.0.2"
    }
}
